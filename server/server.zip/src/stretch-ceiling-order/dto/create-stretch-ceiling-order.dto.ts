export class CreateStretchCeilingOrderDto {

}
