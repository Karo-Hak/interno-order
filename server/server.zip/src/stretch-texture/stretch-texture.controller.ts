import { Controller, Get, Post, Body, Patch, Param, Delete, Res, HttpStatus } from '@nestjs/common';
import { StretchTextureService } from './stretch-texture.service';
import { CreateStretchTextureDto } from './dto/create-stretch-texture.dto';
import { UpdateStretchTextureDto } from './dto/update-stretch-texture.dto';
import { Response } from 'express';


@Controller('stretchTexture')
export class StretchTextureController {
  constructor(private readonly stretchTextureService: StretchTextureService) { }

  @Post()
  async create(@Body() createStretchTextureDto: CreateStretchTextureDto, @Res() res: Response) {
    try {
      return await this.stretchTextureService.create(createStretchTextureDto);
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({
        error: e.message
      })
    }
  }

  @Get()
  async findAll(@Res() res: Response) {
    try {
      const stretchTexture = await this.stretchTextureService.findAll()
      return res.status(HttpStatus.OK).json({
        messege: "ok",
        stretchTexture
      })
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({
        error: e.message
      })
    }
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.stretchTextureService.findOne(+id);
  }

  @Patch('updateStretchTexture')
  async update(@Body() updateStretchTextureDto: UpdateStretchTextureDto, @Res() res: Response) {
    try {
      const stretchTexture = await this.stretchTextureService.update(updateStretchTextureDto._id, updateStretchTextureDto);
      return res.status(HttpStatus.OK).json({
        message: "ok",
        stretchTexture
      });
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({
        error: e.message
      });
    }
  }
  

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.stretchTextureService.remove(+id);
  }
}
