export class CreateCooperationSphereDto {}
