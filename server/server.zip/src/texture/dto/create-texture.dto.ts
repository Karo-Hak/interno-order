export class CreateTextureDto {}
